export default function Menu() {
    return (
        <div>
            menu page
        </div>
    );
  }