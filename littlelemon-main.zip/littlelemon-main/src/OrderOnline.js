export default function OrderOnline() {
    return (
        <div>
            order page
        </div>
    );
  }