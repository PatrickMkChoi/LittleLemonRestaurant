export default function Header() {
    return (
        <header>
            <img src="logo.png" alt="Little Lemon logo"/>
        </header>
    );
  }
