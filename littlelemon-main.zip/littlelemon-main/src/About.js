export default function About() {
    return (
        <div>
            about page
        </div>
    );
  }